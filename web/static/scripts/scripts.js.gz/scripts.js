<script nonce="">
            window.$ = document.querySelector.bind(document);
            window.$$ = document.querySelectorAll.bind(document);
        </script><script nonce="">
            document.addEventListener('alpine:init', () => {
                Alpine.data('dialog', () => ({
                    open: false,
                    dialogToggle() {
                        if (this.open) {
                            return this.dialogClose()
                        }
         
                        this.open = true
                    },
                    dialogClose() {
                        if (!this.open) return

                        const focusAfter = this.$el
                        this.open = false
                        focusAfter && focusAfter.focus()
                    },
                }))
            })
        </script><script nonce="">
            document.addEventListener('alpine:init', () => {
                Alpine.data('accordion', () => ({
                    activeTab: '',
                    setActiveTab() {
                        if(!this.isActive()){
                            this.activeTab = this.$root.getAttribute("tab-id");
                            return;
                        }
                        this.activeTab = '';
                    },
                    isActive() {
                        return this.activeTab === this.$root.getAttribute("tab-id");
                    },
                    getOrientation() {
                        return this.isActive() ? 'rotate-180' : 'rotate-0';
                    },
                    getShrink() {
                        return this.isActive() ? 'grid-rows-[1fr]' : 'grid-rows-[0fr]';
                    },
                }))
            })
        </script><script nonce="">
            document.addEventListener('alpine:init', () => {
                Alpine.data('select', () => ({
                    open: false,
                    selectedLabel: '',
                    selectedValue: '',
                    maxLength: 0,
                    options: new Map(),
                    disabled: new Map(),
                    id() {
                        return ['dropdown-button'];
                    },
		            onEsc() {
                        this.close(this.$refs.button);
                    },
                    onFocus() {
                        !this.$refs.panel.contains(this.$event.target) && this.close();
                    },
                    setDefault() {
                        const label = this.$el.getAttribute("item-label");
                        const value = this.$el.getAttribute("item-value");
                        if (this.selectedLabel === ''){
                            this.setOption(label, value);
                        }
                    },
                    setOption(label, value) {
                        if (label && value) {
                            this.selectedLabel = label; 
                            this.selectedValue = value;
                        }
                    },
                    disableOption: function(value){
                        if (value === '') {
                            return;
                        }
                        let opt = this.options.get(value);
                        this.disabled.set(value, opt);
                        if(this.selectedValue === value){
                            for (let [key, val] of this.options) {
                                 if(!this.disabled.has(key)){
                                    this.selectedLabel = val.getAttribute('item-label');
                                    this.selectedValue = val.getAttribute('item-value');
                                    break;
                                }
                            }
                            if(this.selectedValue === value){
                                this.selectedLabel = '';
                                this.selectedValue = '';
                            }
                        }
                    },
                    clearDisabled: function(){
                        this.disabled = new Map();
                    },
                    toggle() {
                        if (this.open) {
                            return this.close();
                        }
                        this.$refs.button.focus();
                        this.open = true;
                    },
                    setLength(length) {
                        if (length > this.maxLength) {
                            this.maxLength = length;
                        } 
                    },
                    close(focusAfter) {
                        if (!this.open) return;
                        this.open = false;
                        focusAfter && focusAfter.focus();
                    },
                    getTextWidth(text, font) {
                        var canvas = this.getTextWidth.canvas || (this.getTextWidth.canvas = document.createElement('canvas'));
                        var context = canvas.getContext('2d');
                        context.font = font;
                        var metrics = context.measureText(text);
                        return metrics.width;
                    },
                    getCssStyle(element, prop) {
                        return window.getComputedStyle(element, null).getPropertyValue(prop);
                    },
                    getCanvasFont(el = document.body) {
                        const fontWeight = this.getCssStyle(el, 'font-weight') || 'normal';
                        const fontSize = this.getCssStyle(el, 'font-size') || '16px';
                        const fontFamily = this.getCssStyle(el, 'font-family') || 'Times New Roman';
                        return `${fontWeight} ${fontSize} ${fontFamily}`;
                    },
                    display: {
                        ['x-text']() {
                            return this.selectedLabel;
                        },
                        ['x-effect']() {
		                    return this.$el.style.width = `${this.maxLength + 10}px`;
                        }
                    },
                    trigger: {
                        ['x-intersect:leave.full']() {
		                    this.close(this.$refs.button);
                        },
                        ['@click']() {
                            this.toggle();
                        },
                        [':aria-expanded']() {
                            this.open;
                        },
                        [':id']() {
                            this.$id('dropdown-button');
                        },
                    },
                    content:{
                        ['x-show'](){
                            return this.open;
                        },
                        ['x-effect'](){
                            const el = this.$el;
                            this.open && setTimeout(()=>{
                                el.getElementsByTagName('button')[0].focus();
                            },0);
                        },
                        ['x-anchor'](){
                            return this.$refs.button;
                        },
                        ['x-on:mousedown.outside'](){
                            this.close(this.$refs.button);
                        },
                    },
                    item: {
                        ['x-init']() {
                            const label = this.$el.getAttribute("item-label");
                            const value = this.$el.getAttribute("item-value");
                            this.options.set(value, this.$el);
                            this.setLength(this.getTextWidth(label, this.getCanvasFont(this.$el)));
                            if (this.selectedLabel === '') {
                                this.setOption(label, value);
                            }
                        },
                        ['@click.stop'](){
                            this.close(this.$refs.button);
                            this.selectedLabel = this.$el.getAttribute("item-label");
                            this.selectedValue = this.$el.getAttribute("item-value");
                            this.$dispatch('item-clicked');
                        },
                        ['x-effect'](){
                            this.$el.style.width = `${this.maxLength + 50}px`;
                        },
                        [':class'](){
                            return this.disabled.has(this.$el.getAttribute("item-value")) ? "pointer-events-none opacity-50" : "";
                        },
                        ['x-on:keydown.tab.prevent.stop']() {
                             return;
                        },
                        ['x-on:keydown.shift.tab.prevent.stop']() {
                            return;
                        },
                        ['x-on:keydown.down.prevent.stop']() {
                             return this.$el.nextElementSibling && this.$el.nextElementSibling.tagName === 'BUTTON' ? this.$el.nextElementSibling.focus() : this.$el.parentElement.querySelectorAll('button')[0].focus();
                        },
                        ['x-on:keydown.up.prevent.stop']() {
                            return this.$el.previousElementSibling && this.$el.previousElementSibling.tagName === 'BUTTON' ? this.$el.previousElementSibling.focus() : [...this.$el.parentElement.querySelectorAll('button')].pop().focus();
                        }
                    },
                    icon:{
                        ['x-show']() {
                            return this.selectedValue === this.$el.getAttribute("item-value");
                        }
                    },
                    label:{
		                ['x-init']() {
                            this.setLength(this.getTextWidth(this.$el.innerText, this.getCanvasFont(this.$el)));
                        }
                    }
                }))
            })
        </script><script nonce="">
            document.addEventListener('alpine:init', () => {
                Alpine.data('tabs', () => ({
                    activeTab: '',
                    isCurrentTab() {
                        return this.activeTab === this.$el.getAttribute("tab-id")
                    },
                    setActiveTab() {
                        this.activeTab = this.$el.getAttribute("tab-id");
                    },
                }))
            })
        </script><script nonce="">
            document.addEventListener('alpine:init', () => {
                Alpine.data('toggle', () => ({
                    checked: false,
                    Init() {
                        this.checked = !!this.$el.getAttribute("init-state");
                    },
                    getColor() {
                        return this.checked ? 'bg-eGreen' : 'bg-eRed'

                    },
                    getPos() {
                        return this.checked ? 'translate-x-5' : 'translate-x-0'

                    },
                    toggle() {
                        this.checked = !this.checked;
                    }
                }))
            })
        </script><script nonce="">
            document.addEventListener('alpine:init', () => {
                Alpine.data('alert', () => ({
                    open: false,
                    init() {
                        this.$nextTick(()=>{
                            this.open = true;
                            setTimeout(() =>{
                                this.open = false;
                            },5000);
                            setTimeout(() =>{
                                this.$el.remove()
                            },6000);
                        });
                    },
                    close() {
                        this.open = false;
                    },
                }))
            })
        </script><script nonce="">
            document.addEventListener('alpine:init', () => {
                Alpine.data('input', () => ({
                    ["x-on:input"](){
                        let type = this.$event.target.getAttribute('type');
                        if (type === 'number') {
                            this.$event.target.value = this.$event.target.value.replace(/[^0-9]/, '');
                        }

                    }
                }))
            })
        </script><script nonce="">
            document.addEventListener('alpine:init', () => {
                Alpine.data('digitInput', () => ({
                    get legnth(){
                        return this.$el.getAttribute("digits");
                    },
                    value: '',
                    get inputs() {
                        return this.$refs.otpInputContainer.querySelectorAll('.otpInput');
                    },
                    handleInput(e, index) {
                        if (isNaN(e.target.value)) {
                            e.target.value = ''
                            return
                        }
                        const inputValues = [...this.inputs].map(input => input.value);
                        this.value = inputValues.join('');
                        if (e.target.value) {
                            const nextInput = this.inputs[index + 1];
                            if (nextInput) {
                                nextInput.focus();
                                nextInput.select();
                            }
                        }
                    },
                    handlePaste(e) {
                        const paste = e.clipboardData.getData('text').slice(0, this.length);
                        paste.split('').forEach((char, i) => {
                            if (this.inputs[i]) {
                                this.inputs[i].value = char;
                            }
                        });
                        this.value = [...this.inputs].map(input => input.value).join('');
                    },
                    handleBackspace(e, index) {
                        if (index > 0) {
                            this.inputs[index - 1].focus();
                            this.inputs[index - 1].select();
                        }
                    },
                    resetCaret(el) {
                        var val = el.value; 
                        el.value = ''; 
                        el.value = val; 
                    }
                }))
            })
        </script><script nonce="">
            document.addEventListener('alpine:init', () => {
                Alpine.data('dropDownMenu', () => ({
                    open: false,
                    toggle() {
                        if (this.open) {
                            this.$refs.button.firstChild.focus()
                            return this.close()
                        }
                        this.open = true
                    },
                    close(focusAfter) {
                        if (!this.open) return
                        this.open = false
                        focusAfter && focusAfter.focus()
                    },
		            closeEscape(){
                        return this.close(this.$refs.button.firstChild);
                    },
                    idButton : ['dropdown-button'],
                    content:{
                        ["x-ref"](){
                            return "panel"
                        },
                        ["x-show"](){
                            return this.open;
                        },
                        ["x-effect"](){
                            return this.open && setTimeout(()=>this.$el.getElementsByTagName('button')[0].focus(),0)
                        },
                        ["x-anchor"](){
                            return this.$refs.button;
                        },
                        ["x-on:keydown.escape"](){
                            return this.close(this.$refs.button.firstChild);
                        },
                        ["x-on:click.outside"](){
                            return this.close(this.$refs.button.firstChild);
                        },
                        [":id"](){
                            return this.$id('dropdown-button');
                        },
                    },
                    item:{
                        ['x-on:keydown.tab.prevent.stop']() {
                             return;
                        },
                        ['x-on:keydown.shift.tab.prevent.stop']() {
                            return;
                        },
                        ["x-on:keydown.down.prevent.stop"](){
                                return this.$el.nextElementSibling && this.$el.nextElementSibling.tagName === 'BUTTON'
                                ? this.$el.nextElementSibling.focus() 
                                : this.$el.parentElement.querySelectorAll('button')[0].focus()
                        },
                        ["x-on:keydown.up.prevent.stop"](){
                            return this.$el.previousElementSibling&&this.$el.previousElementSibling.tagName === 'BUTTON'
                            ? this.$el.previousElementSibling.focus()
                            : [...this.$el.parentElement.querySelectorAll('button')].pop().focus() 
                        },
                        ["@click"](){
                            this.toggle();
                            this.$dispatch('item-clicked');
                        },
                    },

                }));
                Alpine.data('subDropDownMenu', () => ({
                    open: false,
                    toggle() {
                        if (this.open) {
                            this.$refs.button.firstChild.focus()
                            return this.close()
                        }

                        this.open = true
                    },
                    close(focusAfter) {
                        if (! this.open) return
                        this.open = false
                        focusAfter && focusAfter.focus()
                    },
                    trigger: {
                        ["x-id"](){
                            return ['dropdown-button'];
                        },
                        ["x-on:click"](){
                            return this.toggle();
                        },
                        [":aria-expanded"](){
                            return this.open;
                        },
                        [":aria-controls"](){
                            return this.$id('dropdown-button');
                        },
                        ['x-on:keydown.tab.prevent.stop']() {
                             return;
                        },
                        ['x-on:keydown.shift.tab.prevent.stop']() {
                            return;
                        },
                        ["x-on:keydown.down.prevent.stop"](){
                            return this.$el.nextElementSibling&&this.$el.nextElementSibling.tagName === 'BUTTON'
                            ? this.$el.nextElementSibling.focus() 
                            : this.$el.parentElement.querySelectorAll('button')[0].focus()
                        },
                        ["x-on:keydown.up.prevent.stop"](){
                            return this.$el.previousElementSibling&&this.$el.previousElementSibling.tagName === 'BUTTON'
                            ? this.$el.previousElementSibling.focus()
                            : [...this.$el.parentElement.querySelectorAll('button')].pop().focus() 
                        },
                    },
                    content:{
                        ["x-ref"](){
                            return "panel"
                        },
                        ["x-show"](){
                            return this.open;
                        },
                        ["x-effect"](){
                            return this.open && setTimeout(()=>this.$el.getElementsByTagName('button')[0].focus(),0)
                        },
                        ["x-anchor.right-start"](){
                            return this.$refs.button;
                        },
                        ["x-on:keydown.escape"](){
                            return this.close(this.$refs.button);
                        },
                        ["x-on:click.outside"](){
                            return this.close(this.$refs.button);
                        },
                        [":id"](){
                            return this.$id('dropdown-button');
                        },
                    },
                }));
            })
        </script><script nonce="">
            document.addEventListener('alpine:init', () => {
                Alpine.data('onIntersect', () => ({
                    show: false,
                    showToggle() {
                        this.show = true;
                    },
                }))
            })
        </script><script nonce="">
            document.addEventListener('DOMContentLoaded', function() {
                let isMouseInViewport = false;

                //handles mouse-over-navs (anchor tag)
                const navs = $$("a");
                for(let i=0;i<navs.length;i++){
                    const nav = navs[i];
                    nav.addEventListener('mouseover', function() {
                       const cursors = $$(".cursors");
                        for(let j=0;j<cursors.length;j++){
                            const cursor = cursors[j];
                            cursor.children[0].style.transform = "rotate(-55deg) translateX(-6px) translateY(-6px)"
                            cursor.children[1].style.transform = "rotate(215deg) translateX(-12px) translateY(1px)"
                        }
                    });
                    nav.addEventListener('mouseout', function() {
                       const cursors = $$(".cursors");
                        for(let j=0;j<cursors.length;j++){
                            const cursor = cursors[j];
                            cursor.children[0].style.transform = "rotate(0deg) translateX(0) translateY(0)"
                            cursor.children[1].style.transform = "rotate(35deg) translateX(0) translateY(-2px)"
                        }
                    });
                };

                //determinds if mouse is in viewport or not
                document.body.addEventListener('mouseenter', function() {
                    isMouseInViewport = true;
                });

                document.body.addEventListener('mouseleave', function(e) {
                    isMouseInViewport = false;
                    const cursor = $("#custom-cursor");
                    const cursorTrail = $("#custom-cursor-trail");
                    if(!cursor || !cursorTrail) return;
                    cursor.style.opacity = "0";
                    cursorTrail.style.opacity = "0";
                });

                document.body.addEventListener("mousemove", function(event){
                    const x = event.clientX;
                    const y = event.clientY;
                    const cursor = $("#custom-cursor");
                    const cursorTrail = $("#custom-cursor-trail");
                    if(!cursor || !cursorTrail) return;
                    if(isMouseInViewport) {
                        cursor.style.opacity = "100%";
                    }
                    cursor.style.left = x + "px";
                    cursor.style.top = y + "px";

                    const delay = cursorTrail.getAttribute("delay");
                    setTimeout(function(){
                        if(isMouseInViewport) {
                            cursorTrail.style.opacity = "100%";
                        }
                        cursorTrail.style.left = x -5 + "px";
                        cursorTrail.style.top = y  +5+ "px";
                    }, delay);
                })
                document.body.dispatchEvent(new Event("mousemove"));
            })
        </script><script nonce="">
            document.addEventListener('alpine:init', () => {
                Alpine.data('dropZone', () => ({
                    fileName: "",
                    fileInput:{
                        ["@change"](){
                            return this.fileName = this.$refs.file.files[0].name
                        },
                        ["@dragover"](){
                            return this.$refs.dnd.classList.add('bg-indigo-50')
                        },
                        ["@dragleave"](){
                            return this.$refs.dnd.classList.remove('bg-indigo-50')
                        },
                        ["@drop"](){
                            return this.$refs.dnd.classList.remove('bg-indigo-50')
                        },
                    }

                }))
            })
        </script>